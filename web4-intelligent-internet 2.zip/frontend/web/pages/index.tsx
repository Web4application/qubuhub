export default function Home(){return <h1>Web4</h1>}
